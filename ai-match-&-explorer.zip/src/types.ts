export type Category = 'Chatbot' | 'Coding' | 'Image Generation' | 'Video Creation' | 'Writing' | 'Audio/Voice' | 'Business' | 'Studying' | 'Other';
export type Pricing = 'Free' | 'Freemium' | 'Paid';
export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';
export type Platform = 'Web' | 'Mobile' | 'API' | 'Desktop';

export interface Rating {
  performance: number; // 1-10
  speed: number;       // 1-10
  accuracy: number;    // 1-10
  easeOfUse: number;   // 1-10
}

export interface AITool {
  id: string;
  name: string;
  company: string;
  category: Category;
  shortDescription: string;
  detailedDescription: string;
  pricing: Pricing;
  pricingDetails: string;
  difficulty: Difficulty;
  useCases: string[];
  features: {
    basic: string[];
    advanced: string[];
  };
  pros: string[];
  cons: string[];
  ratings: Rating;
  tags: string[];
  websiteUrl: string;
  platforms: Platform[];
  logo?: string;
  matchReasons?: string[];
}

export interface UserPreferences {
  useCase: Category;
  skillLevel: Difficulty;
  budget: string; // "Free only", "Freemium", "Paid tools OK"
  priority: 'Best quality' | 'Fastest results' | 'Easiest to use' | 'Most powerful';
  platformSelection: Platform[];
}
