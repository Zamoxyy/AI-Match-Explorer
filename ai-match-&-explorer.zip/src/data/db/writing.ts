import { AITool } from '../../types';

export const writingTools: AITool[] = [
  {
    id: "copy-ai",
    name: "Copy.ai",
    company: "Copy.ai",
    category: "Writing",
    shortDescription: "An AI platform built specifically for sales and GTM (Go-To-Market) teams.",
    detailedDescription: "Copy.ai automates sales and marketing workflows. It's excellent for generating email campaigns, personalized sales outreach, and long-form blog posts using multiple AI models acting together.",
    pricing: "Freemium",
    pricingDetails: "Free for 2,000 words/mo. Pro plan is $49/mo for unlimited words.",
    difficulty: "Beginner",
    useCases: ["Writing", "Business"],
    features: {
      basic: ["Templates for ads and emails", "Brand Voice"],
      advanced: ["Automated workflows", "Sales pipeline integration"]
    },
    pros: ["Workflow builder saves massive amounts of time", "Clean, easy interface"],
    cons: ["Generations can be generic without good prompt inputs", "Pricing is high for solo users"],
    ratings: { performance: 8, speed: 9, accuracy: 8, easeOfUse: 9 },
    tags: ["Sales", "Copywriting", "Marketing"],
    websiteUrl: "https://www.copy.ai",
    platforms: ["Web"]
  },
  {
    id: "writesonic",
    name: "Writesonic",
    company: "Writesonic",
    category: "Writing",
    shortDescription: "An SEO-focused AI writer capable of generating real-time factual articles.",
    detailedDescription: "Writesonic is tailored for content creators aiming for Google ranking. It includes ChatGPT-4 capabilities combined with real-time Google Search data to write factually accurate, SEO-optimized articles.",
    pricing: "Freemium",
    pricingDetails: "Free plan (10k words). Paid plans start at $20/mo.",
    difficulty: "Intermediate",
    useCases: ["Writing", "Business"],
    features: {
      basic: ["AI Article Writer", "Paraphraser"],
      advanced: ["SEO integration (SurferSEO)", "Botsonic chatbot"]
    },
    pros: ["Focus on SEO optimization", "Connects to current web data to avoid hallucinations"],
    cons: ["Credit system can be confusing"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 8 },
    tags: ["SEO", "Blogging", "Articles"],
    websiteUrl: "https://writesonic.com",
    platforms: ["Web"]
  },
  {
    id: "quillbot",
    name: "QuillBot",
    company: "Learneo",
    category: "Writing",
    shortDescription: "The ultimate AI paraphrasing and summarizing tool.",
    detailedDescription: "QuillBot is widely used by students and professionals to rewrite sentences, paragraphs, or entire articles. It helps improve fluency, change vocabulary, and condense lengthy texts.",
    pricing: "Freemium",
    pricingDetails: "Free basic paraphrasing. Premium provides unlimited words and advanced modes.",
    difficulty: "Beginner",
    useCases: ["Writing", "Studying"],
    features: {
      basic: ["Paraphrasing", "Grammar checker"],
      advanced: ["Plagiarism checker", "Citation generator"]
    },
    pros: ["Best-in-class paraphrasing engine", "Extensions available for Word, Chrome"],
    cons: ["Not a text generator from scratch", "Free tier is somewhat restrictive"],
    ratings: { performance: 9, speed: 10, accuracy: 9, easeOfUse: 10 },
    tags: ["Paraphrasing", "Editing", "Students"],
    websiteUrl: "https://quillbot.com",
    platforms: ["Web", "Desktop"]
  },
  {
    id: "rytr",
    name: "Rytr",
    company: "Rytr",
    category: "Writing",
    shortDescription: "An affordable, easy-to-use AI writing assistant for short-form content.",
    detailedDescription: "Rytr generates high-quality emails, social media posts, and ad copy rapidly, making it great for solo entrepreneurs.",
    pricing: "Freemium",
    pricingDetails: "Free tier available. Saver plan is $9/mo.",
    difficulty: "Beginner",
    useCases: ["Writing", "Business"],
    features: {
      basic: ["40+ use cases", "30+ languages"],
      advanced: ["Built-in plagiarism checker", "Magic command writing"]
    },
    pros: ["Very affordable compared to competitors", "Simple interface"],
    cons: ["Struggles with long-form content", "Output quality sometimes requires editing"],
    ratings: { performance: 7, speed: 9, accuracy: 7, easeOfUse: 10 },
    tags: ["Affordable", "Short-form"],
    websiteUrl: "https://rytr.me",
    platforms: ["Web"]
  },
  {
    id: "sudowrite",
    name: "Sudowrite",
    company: "Sudowrite",
    category: "Writing",
    shortDescription: "An AI tool built specifically for fiction writers and novelists.",
    detailedDescription: "Sudowrite uses AI to help you write fiction. It helps with brainstorming, character development, world-building, pacing, and famously, 'showing, not telling'.",
    pricing: "Paid",
    pricingDetails: "Starts at $19/mo.",
    difficulty: "Intermediate",
    useCases: ["Writing", "Entertainment"],
    features: {
      basic: ["Story Engine", "Brainstorming"],
      advanced: ["Describe feature (focuses on senses)", "Pacing tools"]
    },
    pros: ["Unmatched tool for fiction", "Helps push through writer's block"],
    cons: ["Not suitable for factual writing"],
    ratings: { performance: 9, speed: 8, accuracy: 8, easeOfUse: 8 },
    tags: ["Fiction", "Novel Writing"],
    websiteUrl: "https://www.sudowrite.com",
    platforms: ["Web"]
  },
  {
    id: "frase",
    name: "Frase",
    company: "Frase",
    category: "Writing",
    shortDescription: "AI tool that helps you research, write, and optimize SEO content.",
    detailedDescription: "Frase analyzes search results for a given keyword and creates a detailed content brief, then helps you write an article that is statistically likely to rank on Google.",
    pricing: "Paid",
    pricingDetails: "Starts at $14.99/mo.",
    difficulty: "Intermediate",
    useCases: ["Writing", "Business"],
    features: {
      basic: ["Content Brief generation", "SEO scoring"],
      advanced: ["Automated content outlines"]
    },
    pros: ["Streamlines SEO research massively", "Scoring system acts like a game"],
    cons: ["Interface has a learning curve"],
    ratings: { performance: 8, speed: 8, accuracy: 9, easeOfUse: 7 },
    tags: ["SEO", "Content Strategy"],
    websiteUrl: "https://www.frase.io",
    platforms: ["Web"]
  },
  {
    id: "surfer-seo",
    name: "Surfer SEO",
    company: "Surfer",
    category: "Writing",
    shortDescription: "Data-driven SEO tool combined with a one-click AI article generator.",
    detailedDescription: "Surfer SEO is primarily a premier on-page SEO optimization tool that generates complete, highly-optimized articles designed specifically to rank on page 1.",
    pricing: "Paid",
    pricingDetails: "Starts at $89/mo. AI articles cost roughly $29 per article.",
    difficulty: "Intermediate",
    useCases: ["Writing", "Business"],
    features: {
      basic: ["Content Editor", "Keyword Research"],
      advanced: ["Surfer AI (one click article generation)", "SERP Analyzer"]
    },
    pros: ["Definitive industry standard for SEO", "Generates ready-to-rank articles"],
    cons: ["Extremely expensive", "Charges per article on top of subscription"],
    ratings: { performance: 10, speed: 9, accuracy: 9, easeOfUse: 7 },
    tags: ["SEO", "Professional"],
    websiteUrl: "https://surferseo.com",
    platforms: ["Web"]
  },
  {
    id: "writer-ai",
    name: "Writer",
    company: "Writer",
    category: "Writing",
    shortDescription: "Full-stack generative AI platform built entirely for the enterprise.",
    detailedDescription: "Writer offers an AI writing platform that strictly adheres to corporate style guides, terminology, and brand voice. It ensures no data is used to train out-of-network models.",
    pricing: "Paid",
    pricingDetails: "Starts at $18/user/mo for teams.",
    difficulty: "Intermediate",
    useCases: ["Writing", "Business"],
    features: {
      basic: ["Brand voice enforcement", "Style guide adherence"],
      advanced: ["Palmyra LLM", "Custom app building"]
    },
    pros: ["Safest option for strict corporate compliance", "Enforces style rules automatically"],
    cons: ["Not aimed at casual users"],
    ratings: { performance: 9, speed: 8, accuracy: 9, easeOfUse: 8 },
    tags: ["Enterprise", "Compliance"],
    websiteUrl: "https://writer.com",
    platforms: ["Web", "Desktop"]
  }
];
