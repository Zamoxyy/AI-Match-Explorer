import { AITool } from '../../types';

export const studyingTools: AITool[] = [
  {
    id: "elicit",
    name: "Elicit",
    company: "Ought",
    category: "Studying",
    shortDescription: "An AI research assistant that analyzes academic papers.",
    detailedDescription: "Elicit uses language models to help automate research workflows, like parts of literature review. It searches semantics across a database of 100+ million academic papers to answer your research questions.",
    pricing: "Freemium",
    pricingDetails: "Free basic searches. Plus plan offers more credits and data exports.",
    difficulty: "Intermediate",
    useCases: ["Studying", "Research", "Writing"],
    features: {
      basic: ["Semantic paper search", "Abstract summarization"],
      advanced: ["Data extraction into tables", "Finding logical flaws in methodologies"]
    },
    pros: ["A must-have for grad students and academics", "Drastically reduces time doing literature reviews", "Highly factual, cites real papers"],
    cons: ["Only as good as the underlying Semantic Scholar database", "Can be confusing for non-academics"],
    ratings: { performance: 9, speed: 8, accuracy: 9, easeOfUse: 7 },
    tags: ["Academic", "Literature Review", "Research"],
    websiteUrl: "https://elicit.org",
    platforms: ["Web"]
  },
  {
    id: "consensus",
    name: "Consensus",
    company: "Consensus",
    category: "Studying",
    shortDescription: "A search engine that uses AI to find answers in scientific research.",
    detailedDescription: "Consensus focuses on answering yes/no or informational questions by cross-referencing thousands of peer-reviewed papers. It provides a 'consensus meter' showing what the majority of science agrees on.",
    pricing: "Freemium",
    pricingDetails: "Free basic searching. Premium unlocks unlimited AI summaries.",
    difficulty: "Beginner",
    useCases: ["Studying", "Research", "Other"],
    features: {
      basic: ["Scientific question answering", "Paper citations"],
      advanced: ["Consensus Meter", "Integration with ChatGPT Plus (Plugin/GPT)"]
    },
    pros: ["Excellent way to debunk myths with real science", "Very consumer-friendly interface compared to Elicit"],
    cons: ["Not ideal for open-ended brainstorming"],
    ratings: { performance: 8, speed: 9, accuracy: 10, easeOfUse: 9 },
    tags: ["Search Engine", "Science", "Fact-checking"],
    websiteUrl: "https://consensus.app",
    platforms: ["Web"]
  },
  {
    id: "notebooklm",
    name: "NotebookLM",
    company: "Google",
    category: "Studying",
    shortDescription: "A personalized AI research assistant grounded automatically in your own documents.",
    detailedDescription: "Google's NotebookLM allows you to upload PDFs, Google Docs, and notes to create an expert AI on your specific data. It famously features an 'Audio Overview' that turns your notes into a conversational podcast.",
    pricing: "Free",
    pricingDetails: "Currently free globally (experimental).",
    difficulty: "Beginner",
    useCases: ["Studying", "Research", "Other"],
    features: {
      basic: ["Grounded QA on your documents", "Auto-citations"],
      advanced: ["Audio Overview (Podcast generation)", "Study guide generation"]
    },
    pros: ["The Audio Overview podcast feature is mind-blowing for auditory learners", "Will not hallucinate outside the given documents"],
    cons: ["Source limit per notebook (though generous)"],
    ratings: { performance: 9, speed: 9, accuracy: 9, easeOfUse: 9 },
    tags: ["Notes", "Podcast", "RAG"],
    websiteUrl: "https://notebooklm.google.com",
    platforms: ["Web"]
  },
  {
    id: "khanmigo",
    name: "Khanmigo",
    company: "Khan Academy",
    category: "Studying",
    shortDescription: "An AI guide that asks questions rather than giving direct answers.",
    detailedDescription: "Khanmigo acts as a Socratic tutor. Designed for students, it refuses to simply do your homework; instead, it guides you step-by-step through solving math problems, learning history, and writing essays.",
    pricing: "Paid",
    pricingDetails: "$4/mo or $44/yr. Free for teachers.",
    difficulty: "Beginner",
    useCases: ["Studying", "Education"],
    features: {
      basic: ["Socratic tutoring", "Homework help"],
      advanced: ["Lesson planning (for teachers)", "Chat with historical figures"]
    },
    pros: ["Incredible safety and pedagogical structure", "Free for educators", "Actually helps kids learn rather than cheat"],
    cons: ["Students looking for 'quick answers' will find it frustrating"],
    ratings: { performance: 9, speed: 8, accuracy: 9, easeOfUse: 9 },
    tags: ["Tutor", "Education", "K-12"],
    websiteUrl: "https://www.khanacademy.org/khan-labs",
    platforms: ["Web"]
  },
  {
    id: "socratic",
    name: "Socratic by Google",
    company: "Google",
    category: "Studying",
    shortDescription: "A mobile app that helps students understand their school work.",
    detailedDescription: "Socratic lets students take a photo of a tricky homework problem. The AI then uses computer vision and Google Search to find explainers, videos, and step-by-step help.",
    pricing: "Free",
    pricingDetails: "Completely free app.",
    difficulty: "Beginner",
    useCases: ["Studying", "Education"],
    features: {
      basic: ["Photo-to-answer", "Subject-specific explainers"],
      advanced: ["Computer Vision math solver"]
    },
    pros: ["Extremely easy to use for students on mobile", "Visual aids are very helpful"],
    cons: ["Less of a conversational AI compared to standard chatbots", "Hasn't seen massive updates recently"],
    ratings: { performance: 7, speed: 9, accuracy: 8, easeOfUse: 10 },
    tags: ["Mobile", "Homework", "Visual Search"],
    websiteUrl: "https://socratic.org",
    platforms: ["Mobile"]
  },
  {
    id: "duolingo-max",
    name: "Duolingo Max",
    company: "Duolingo",
    category: "Studying",
    shortDescription: "AI-powered roleplay and explanation features for language learning.",
    detailedDescription: "Duolingo Max incorporates OpenAI's GPT-4 to offer two new major features: 'Explain My Answer' (which tells you exactly why a grammar translation was wrong) and 'Roleplay' (conversating with AI personas).",
    pricing: "Paid",
    pricingDetails: "Highest tier subscription above Super Duolingo.",
    difficulty: "Beginner",
    useCases: ["Studying", "Education"],
    features: {
      basic: ["Explain My Answer", "Roleplay conversations"],
      advanced: ["Adaptive difficulty in roleplay", "Post-conversation review"]
    },
    pros: ["Roleplays genuinely feel like practicing with a patient native speaker", "Fills the gap between app learning and actual speaking"],
    cons: ["Very expensive subscription tier", "Currently limited to specific languages (e.g., Spanish, French)"],
    ratings: { performance: 9, speed: 10, accuracy: 9, easeOfUse: 10 },
    tags: ["Language", "Roleplay", "Tutor"],
    websiteUrl: "https://www.duolingo.com",
    platforms: ["Mobile", "Web"]
  }
];
