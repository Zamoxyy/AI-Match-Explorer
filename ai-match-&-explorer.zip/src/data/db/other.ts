import { AITool } from '../../types';

export const otherTools: AITool[] = [
  {
    id: "openai-api",
    name: "OpenAI API",
    company: "OpenAI",
    category: "Other",
    shortDescription: "The industry-standard API for integrating LLMs into applications.",
    detailedDescription: "The OpenAI API provides developers access to models like GPT-4o, GPT-4 Turbo, DALL-E 3, and Whisper. It is the backbone of thousands of third-party AI applications.",
    pricing: "Paid",
    pricingDetails: "Pay-as-you-go based on token usage.",
    difficulty: "Advanced",
    useCases: ["Coding", "Business", "Other"],
    features: {
      basic: ["Text generation", "Embeddings"],
      advanced: ["Function calling", "Vision capabilities", "Fine-tuning"]
    },
    pros: ["Most robust and mature ecosystem", "Excellent documentation and libraries"],
    cons: ["Can get expensive at high scale", "Lock-in to OpenAI's ecosystem"],
    ratings: { performance: 10, speed: 8, accuracy: 9, easeOfUse: 6 },
    tags: ["API", "Developers", "Infrastructure"],
    websiteUrl: "https://platform.openai.com",
    platforms: ["API"]
  },
  {
    id: "hugging-face",
    name: "Hugging Face",
    company: "Hugging Face",
    category: "Other",
    shortDescription: "The 'GitHub of Machine Learning' offering models, datasets, and spaces.",
    detailedDescription: "Hugging Face is an open-source hub that hosts hundreds of thousands of AI models (Transformers, Diffusers) and datasets. Developers use it to find, train, and deploy open-source models.",
    pricing: "Freemium",
    pricingDetails: "Free to host models/datasets. Paid for Inference Endpoints and Pro Spaces.",
    difficulty: "Advanced",
    useCases: ["Coding", "Other", "Research"],
    features: {
      basic: ["Model hosting repository", "Datasets Hub"],
      advanced: ["Serverless Inference APIs", "AutoTrain (no-code fine-tuning)", "Spaces (Gradio/Streamlit hosting)"]
    },
    pros: ["The undisputed center of open-source AI", "Massive community and resources", "Incredible Transformers library"],
    cons: ["Overwhelming for non-developers", "Quality of community models varies wildly"],
    ratings: { performance: 9, speed: 8, accuracy: 8, easeOfUse: 5 },
    tags: ["Open Source", "Hub", "Machine Learning"],
    websiteUrl: "https://huggingface.co",
    platforms: ["Web", "API", "Desktop"]
  },
  {
    id: "zapier-ai",
    name: "Zapier Central / AI",
    company: "Zapier",
    category: "Other",
    shortDescription: "AI automation platform integrating thousands of apps.",
    detailedDescription: "Zapier integrates AI into its automation workflows, allowing users to build custom AI bots (Central) that trigger actions across 6,000+ business applications.",
    pricing: "Freemium",
    pricingDetails: "Free basic zaps. Paid plans start at $20/mo.",
    difficulty: "Intermediate",
    useCases: ["Business", "Other"],
    features: {
      basic: ["AI steps in workflows", "Custom Chatbots"],
      advanced: ["Data parsing via AI", "Multi-step complex conditional logic"]
    },
    pros: ["Incredible integration ecosystem", "No-code setup for complex API workflows"],
    cons: ["Pricing scales aggressively with usage"],
    ratings: { performance: 8, speed: 9, accuracy: 8, easeOfUse: 8 },
    tags: ["Automation", "No-Code", "Integration"],
    websiteUrl: "https://zapier.com",
    platforms: ["Web"]
  },
  {
    id: "autogpt",
    name: "AutoGPT",
    company: "Open Source",
    category: "Other",
    shortDescription: "An experimental open-source proxy that attempts to make GPT-4 fully autonomous.",
    detailedDescription: "AutoGPT was one of the first popular autonomous agents. You give it a high-level goal, and it chains together thoughts, actions (like web searching or file writing), and criticisms to accomplish the task.",
    pricing: "Free",
    pricingDetails: "Open source, but requires your own API keys (which can burn through credits quickly).",
    difficulty: "Advanced",
    useCases: ["Coding", "Research", "Other"],
    features: {
      basic: ["Goal-oriented execution", "Web browsing"],
      advanced: ["Long-term memory", "File execution"]
    },
    pros: ["Fascinating glimpse into the future of autonomous systems", "Highly customizable"],
    cons: ["Often gets stuck in infinite loops", "Can be very expensive in API costs if unmonitored"],
    ratings: { performance: 6, speed: 7, accuracy: 5, easeOfUse: 4 },
    tags: ["Agent", "Autonomous", "Experimental"],
    websiteUrl: "https://github.com/Significant-Gravitas/AutoGPT",
    platforms: ["Desktop", "API"]
  },
  {
    id: "canva-ai",
    name: "Canva Magic Studio",
    company: "Canva",
    category: "Image Generation",
    shortDescription: "A suite of accessible AI design tools built into Canva.",
    detailedDescription: "Magic Studio brings generative AI to everyone. It allows users to generate images, remove backgrounds instantly, rewrite ad copy, and auto-format presentations without needing professional design skills.",
    pricing: "Freemium",
    pricingDetails: "Some free AI uses. Full access requires Canva Pro ($15/mo).",
    difficulty: "Beginner",
    useCases: ["Business", "Image Generation", "Design"],
    features: {
      basic: ["Magic Media (Text-to-Image/Video)", "Background Remover"],
      advanced: ["Magic Morph (Text effects)", "Magic Switch (Resize arrays instantly)"]
    },
    pros: ["The most user-friendly AI design tools on the market", "All-in-one platform for social media creators"],
    cons: ["Lacks the granular control of Photoshop Firefly"],
    ratings: { performance: 8, speed: 10, accuracy: 8, easeOfUse: 10 },
    tags: ["Design", "Accessible", "Social Media"],
    websiteUrl: "https://www.canva.com/magic/",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "framer-ai",
    name: "Framer AI",
    company: "Framer",
    category: "Other",
    shortDescription: "AI that designs and publishes complete websites from text prompts.",
    detailedDescription: "Framer is a powerful web design tool that now includes generative AI. You can describe a website landing page, and it will generate the layout, copy, and color palette, which you can publish instantly.",
    pricing: "Freemium",
    pricingDetails: "Free to design. Paid hosting/custom domains start at $15/mo.",
    difficulty: "Intermediate",
    useCases: ["Business", "Design", "Coding"],
    features: {
      basic: ["Prompt-to-website", "AI Copywriting"],
      advanced: ["Color palette generation", "Responsive layout morphing"]
    },
    pros: ["Extremely fast way to wireframe landing pages", "Framer's publishing engine is blazingly fast"],
    cons: ["Initial AI designs can look slightly generic", "Framer's learning curve can be steep for complex animations"],
    ratings: { performance: 8, speed: 9, accuracy: 7, easeOfUse: 7 },
    tags: ["Web Design", "No-Code", "Landing Pages"],
    websiteUrl: "https://www.framer.com/ai",
    platforms: ["Web", "Desktop"]
  },
  {
    id: "alphafold",
    name: "AlphaFold",
    company: "Google DeepMind",
    category: "Other",
    shortDescription: "A revolutionary AI system that predicts 3D protein structures.",
    detailedDescription: "AlphaFold fundamentally changed biology by accurately predicting how proteins fold based on their amino acid sequences, solving a 50-year-old grand challenge in science.",
    pricing: "Free",
    pricingDetails: "The AlphaFold Database is freely accessible to the scientific community.",
    difficulty: "Advanced",
    useCases: ["Research", "Other", "Science"],
    features: {
      basic: ["Protein structure prediction", "Database search"],
      advanced: ["Molecular docking (AlphaFold 3)", "Drug discovery integration"]
    },
    pros: ["Has saved scientists decades of manual lab work", "Won the Nobel Prize in Chemistry (Demis Hassabis & John Jumper)"],
    cons: ["Requires high-level domain expertise to utilize the data"],
    ratings: { performance: 10, speed: 9, accuracy: 10, easeOfUse: 3 },
    tags: ["Science", "Biology", "DeepMind"],
    websiteUrl: "https://alphafold.ebi.ac.uk",
    platforms: ["Web", "API", "Desktop"]
  }
];
