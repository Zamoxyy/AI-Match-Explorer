import { AITool } from '../../types';

export const audioTools: AITool[] = [
  {
    id: "murf-ai",
    name: "Murf AI",
    company: "Murf",
    category: "Audio/Voice",
    shortDescription: "A versatile AI voice generator tailored for professional voiceovers.",
    detailedDescription: "Murf AI provides studio-quality voiceovers in minutes. It is geared towards creating voiceovers for presentations, YouTube videos, and e-learning, offering a powerful studio editor to adjust pitch, pace, and emphasis.",
    pricing: "Freemium",
    pricingDetails: "Free trial to try voices. Paid plans start at $19/mo.",
    difficulty: "Beginner",
    useCases: ["Audio/Voice", "Business", "Video Creation"],
    features: {
      basic: ["Text-to-speech", "120+ standard voices"],
      advanced: ["Voice changer", "Timeline editor to sync with video", "Canva integration"]
    },
    pros: ["Excellent audio-video syncing capabilities in the studio", "Large library of professional-sounding voices"],
    cons: ["Less emotional range than ElevenLabs", "Pricing limits generation time strictly"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 9 },
    tags: ["Voiceovers", "Corporate", "E-Learning"],
    websiteUrl: "https://murf.ai",
    platforms: ["Web"]
  },
  {
    id: "playht",
    name: "PlayHT",
    company: "PlayHT",
    category: "Audio/Voice",
    shortDescription: "Ultra-realistic text-to-speech and AI voice cloning platform.",
    detailedDescription: "PlayHT is a direct competitor to ElevenLabs, offering highly expressive voices and real-time streaming APIs. It's excellent for podcasts, game development, and conversational AI agents.",
    pricing: "Freemium",
    pricingDetails: "Free for non-commercial use with limits. Paid plans start at $31/mo.",
    difficulty: "Intermediate",
    useCases: ["Audio/Voice", "Coding", "Entertainment"],
    features: {
      basic: ["Text-to-speech", "Voice cloning"],
      advanced: ["Real-time API", "Pronunciation library", "SSML support"]
    },
    pros: ["Extremely fast real-time API latency", "Voice cloning needs very little audio data"],
    cons: ["Interface can be somewhat cluttered", "High price point for unlimited generation"],
    ratings: { performance: 9, speed: 9, accuracy: 8, easeOfUse: 8 },
    tags: ["API", "Voice Cloning", "Podcasts"],
    websiteUrl: "https://play.ht",
    platforms: ["Web", "API"]
  },
  {
    id: "speechify",
    name: "Speechify",
    company: "Speechify",
    category: "Audio/Voice",
    shortDescription: "The #1 AI text-to-speech reader to boost productivity and accessibility.",
    detailedDescription: "Speechify focuses on reading text aloud to you. It uses AI to read books, articles, emails, and PDFs in high-quality, natural-sounding voices, including voices of celebrities like Snoop Dogg.",
    pricing: "Freemium",
    pricingDetails: "Free basic reading. Premium is $139/year for high-quality AI voices and fast reading speeds.",
    difficulty: "Beginner",
    useCases: ["Studying", "Audio/Voice", "Productivity"],
    features: {
      basic: ["Read documents/web pages aloud", "Speed control"],
      advanced: ["Celebrity voices", "Optical Character Recognition (OCR) to read physical books"]
    },
    pros: ["Incredible tool for ADHD, dyslexia, or general studying", "Available on almost every platform/browser"],
    cons: ["Premium subscription is a hefty upfront annual cost", "Not built for creating downloadable voiceover files (though they have a separate studio product)"],
    ratings: { performance: 8, speed: 10, accuracy: 9, easeOfUse: 10 },
    tags: ["Accessibility", "Reader", "Studying"],
    websiteUrl: "https://speechify.com",
    platforms: ["Web", "Mobile", "Desktop"]
  },
  {
    id: "resemble-ai",
    name: "Resemble AI",
    company: "Resemble AI",
    category: "Audio/Voice",
    shortDescription: "Enterprise-grade generative voice AI focused on safety and scale.",
    detailedDescription: "Resemble AI is geared towards game developers and enterprises. They offer robust voice cloning, deepfake detection, and dynamic audio generation APIs.",
    pricing: "Paid",
    pricingDetails: "Usage-based pricing (per second) or Custom Enterprise.",
    difficulty: "Advanced",
    useCases: ["Audio/Voice", "Business", "Coding"],
    features: {
      basic: ["Voice cloning", "Text-to-speech"],
      advanced: ["Deepfake Watermarking", "Real-time voice changing", "Programmatic API"]
    },
    pros: ["Industry-leading focus on security and deepfake prevention", "Very granular API control"],
    cons: ["Not aimed at casual consumer usage", "More complex to set up"],
    ratings: { performance: 8, speed: 9, accuracy: 9, easeOfUse: 6 },
    tags: ["Enterprise", "Security", "Gaming"],
    websiteUrl: "https://www.resemble.ai",
    platforms: ["Web", "API"]
  },
  {
    id: "voicemod",
    name: "Voicemod",
    company: "Voicemod",
    category: "Audio/Voice",
    shortDescription: "Real-time AI voice changer and soundboard for gamers and streamers.",
    detailedDescription: "Voicemod adds real-time voice modification to your microphone output. It uses AI to completely change your voice to sound like an alien, a robot, a celebrity, or a realistic human of another gender.",
    pricing: "Freemium",
    pricingDetails: "Free changing with daily rotating voices. Pro tier unlocks all voices and custom soundboards.",
    difficulty: "Beginner",
    useCases: ["Entertainment", "Audio/Voice", "Gaming"],
    features: {
      basic: ["Real-time voice changing", "Soundboard"],
      advanced: ["AI Voices (high fidelity modification)", "Custom voice creator"]
    },
    pros: ["Works instantly with Discord, OBS, games", "Incredibly fun and easy to use"],
    cons: ["Requires installing virtual audio drivers on your PC", "Some AI voices have high latency"],
    ratings: { performance: 8, speed: 10, accuracy: 7, easeOfUse: 9 },
    tags: ["Gaming", "VTubers", "Real-time"],
    websiteUrl: "https://www.voicemod.net",
    platforms: ["Desktop", "Mobile"]
  },
  {
    id: "aiva",
    name: "AIVA",
    company: "AIVA",
    category: "Audio/Voice",
    shortDescription: "The AI music generation assistant designed for composers.",
    detailedDescription: "AIVA (Artificial Intelligence Virtual Artist) is designed to help composers brainstorm and create background music. It allows you to generate music in predefined styles and export MIDI files to edit in your own DAW.",
    pricing: "Freemium",
    pricingDetails: "Free tier uses CC BY license. Pro plans ($33/mo) grant full copyright ownership.",
    difficulty: "Advanced",
    useCases: ["Audio/Voice", "Entertainment"],
    features: {
      basic: ["Generate music by genre", "Preset emotional moods"],
      advanced: ["MIDI file export", "Influence generation with your own audio files"]
    },
    pros: ["Being able to export MIDI is a game-changer for producers", "Focuses on instrumental/cinematic music"],
    cons: ["Does not generate vocals", "Interface is more technical than Suno/Udio"],
    ratings: { performance: 8, speed: 8, accuracy: 7, easeOfUse: 6 },
    tags: ["Music", "Composers", "MIDI"],
    websiteUrl: "https://www.aiva.ai",
    platforms: ["Web", "Desktop"]
  },
  {
    id: "soundraw",
    name: "Soundraw",
    company: "Soundraw",
    category: "Audio/Voice",
    shortDescription: "AI music generator focused on providing royalty-free beats for creators.",
    detailedDescription: "Soundraw allows video creators and podcasters to generate royalty-free background music by selecting the mood, genre, and length. You can heavily customize the generated tracks.",
    pricing: "Paid",
    pricingDetails: "Starts at $16.99/mo for unlimited downloads and commercial use.",
    difficulty: "Beginner",
    useCases: ["Audio/Voice", "Video Creation", "Business"],
    features: {
      basic: ["Mood-based generation", "Customizable length"],
      advanced: ["Edit song structure (Chorus, Verse energy)", "Stems download (Pro)"]
    },
    pros: ["Completely royalty-free and safe for YouTube/Twitch", "Song structure editor is brilliant for syncing to video"],
    cons: ["No vocals generated", "Can sound a bit 'stock music' compared to Udio"],
    ratings: { performance: 8, speed: 9, accuracy: 8, easeOfUse: 9 },
    tags: ["Royalty-Free", "Background Music", "Video Editing"],
    websiteUrl: "https://soundraw.io",
    platforms: ["Web"]
  }
];
