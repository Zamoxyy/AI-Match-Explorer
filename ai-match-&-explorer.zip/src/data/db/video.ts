import { AITool } from '../../types';

export const videoTools: AITool[] = [
  {
    id: "pika-labs",
    name: "Pika Labs",
    company: "Pika",
    category: "Video Creation",
    shortDescription: "An idea-to-video platform that brings your creativity to motion.",
    detailedDescription: "Pika is a fast-growing text-to-video AI. It specializes in generating 3D animation, anime, and cinematic videos from text or images, and features tools like lip-syncing and region modification.",
    pricing: "Freemium",
    pricingDetails: "Free daily credits. Pro plans for watermarks removal and more time.",
    difficulty: "Intermediate",
    useCases: ["Video Creation", "Marketing", "Entertainment"],
    features: {
      basic: ["Text-to-video", "Image-to-video"],
      advanced: ["Lip sync", "Modify specific regions of a video (Inpainting)"]
    },
    pros: ["Very fast generation", "Lip sync feature is easy to use", "Great at animated/3D styles"],
    cons: ["Realism can struggle compared to Sora or Gen-3", "Generations are short"],
    ratings: { performance: 8, speed: 9, accuracy: 7, easeOfUse: 8 },
    tags: ["Animations", "Fast Video"],
    websiteUrl: "https://pika.art",
    platforms: ["Web", "Desktop"]
  },
  {
    id: "heygen",
    name: "HeyGen",
    company: "HeyGen",
    category: "Video Creation",
    shortDescription: "Create studio-quality videos with AI avatars and voice clones.",
    detailedDescription: "HeyGen focuses heavily on marketing and training videos. It allows you to create highly realistic AI avatars, clone your own voice, and tranzinc videos seamlessly into other languages.",
    pricing: "Paid",
    pricingDetails: "Creator plan starts at $29/mo.",
    difficulty: "Beginner",
    useCases: ["Video Creation", "Business", "Marketing"],
    features: {
      basic: ["AI Avatars", "Text-to-speech"],
      advanced: ["Instant Avatar (clone yourself via webcam)", "Video translation with lip-sync"]
    },
    pros: ["Instant Avatar cloning is incredibly fast and uncanny", "Great for scaling marketing content", "Flawless video translation"],
    cons: ["Can be expensive for high volume", "Avatars lack deep emotional range"],
    ratings: { performance: 9, speed: 9, accuracy: 9, easeOfUse: 9 },
    tags: ["Avatars", "Marketing", "Translation"],
    websiteUrl: "https://www.heygen.com",
    platforms: ["Web"]
  },
  {
    id: "invideo-ai",
    name: "InVideo AI",
    company: "InVideo",
    category: "Video Creation",
    shortDescription: "Generates complete, publish-ready videos from a simple text prompt.",
    detailedDescription: "InVideo AI is the ultimate YouTube shorts/faceless channel generator. You give it a topic, and it writes the script, generates an AI voiceover, sources B-roll footage, and adds subtitles automatically.",
    pricing: "Freemium",
    pricingDetails: "Free plan with watermarks. Paid plans start at $20/mo.",
    difficulty: "Beginner",
    useCases: ["Video Creation", "Business", "Social Media"],
    features: {
      basic: ["Prompt-to-full-video", "Stock footage sourcing"],
      advanced: ["Edit video via chat commands", "Voice cloning"]
    },
    pros: ["Easiest way to make a YouTube Short in 2 minutes", "Magic edit via text is very intuitive"],
    cons: ["Relies heavily on stock footage rather than generated AI video", "Can feel slightly generic"],
    ratings: { performance: 8, speed: 10, accuracy: 7, easeOfUse: 10 },
    tags: ["YouTube Shorts", "Social Media", "Automation"],
    websiteUrl: "https://invideo.io",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "kapwing-ai",
    name: "Kapwing",
    company: "Kapwing",
    category: "Video Creation",
    shortDescription: "An online video editor supercharged with AI tools.",
    detailedDescription: "Kapwing is an accessible online video editor that integrates AI for tedious tasks like removing silences, generating subtitles, and automatically turning long videos into short clips.",
    pricing: "Freemium",
    pricingDetails: "Free with watermarks and limits. Pro is $16/mo.",
    difficulty: "Beginner",
    useCases: ["Video Creation", "Social Media"],
    features: {
      basic: ["Timeline editing", "Auto-subtitles"],
      advanced: ["Smart Cut (remove silence)", "Text-to-video blocks"]
    },
    pros: ["Browser-based and very easy to learn", "Excellent auto-subtitles", "Great for meme and social media editing"],
    cons: ["Can be laggy with large files in the browser"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 9 },
    tags: ["Editor", "Subtitles", "Social Media"],
    websiteUrl: "https://www.kapwing.com",
    platforms: ["Web"]
  },
  {
    id: "colossyan",
    name: "Colossyan",
    company: "Colossyan",
    category: "Video Creation",
    shortDescription: "AI video creator specifically designed for workplace learning and corporate training.",
    detailedDescription: "Colossyan focuses on the enterprise learning sector, allowing users to create instructional videos with multiple AI avatars having conversations with each other.",
    pricing: "Paid",
    pricingDetails: "Starts at around $21/mo.",
    difficulty: "Beginner",
    useCases: ["Video Creation", "Business", "Studying"],
    features: {
      basic: ["AI Avatars", "Screen recording integration"],
      advanced: ["Conversation mode (multiple avatars)", "SCORM export for LMS"]
    },
    pros: ["Conversation mode is unique and engaging", "Perfect for replacing boring PowerPoint trainings"],
    cons: ["Not meant for creative or cinematic video generation"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 9 },
    tags: ["Corporate Training", "Avatars", "E-Learning"],
    websiteUrl: "https://www.colossyan.com",
    platforms: ["Web"]
  }
];
