import { AITool } from '../../types';

export const imageTools: AITool[] = [
  {
    id: "adobe-firefly",
    name: "Adobe Firefly",
    company: "Adobe",
    category: "Image Generation",
    shortDescription: "Commercially safe generative AI integrated into Adobe's creative suite.",
    detailedDescription: "Firefly is Adobe's family of creative generative AI models. It is designed to be commercially safe (trained on Adobe Stock) and is built directly into Photoshop, Illustrator, and other Adobe apps.",
    pricing: "Paid",
    pricingDetails: "Requires Adobe Creative Cloud subscription.",
    difficulty: "Beginner",
    useCases: ["Image Generation", "Business", "Design"],
    features: {
      basic: ["Generative Fill", "Text-to-image"],
      advanced: ["Vector recoloring", "Text effects", "Seamless Photoshop integration"]
    },
    pros: ["Commercially safe to use", "Generative Fill in Photoshop is industry-leading", "Easy to use"],
    cons: ["Generations can sometimes lack the artistic flair of Midjourney", "Requires an expensive Adobe subscription"],
    ratings: { performance: 9, speed: 8, accuracy: 9, easeOfUse: 9 },
    tags: ["Design", "Photoshop", "Commercial Safe"],
    websiteUrl: "https://firefly.adobe.com",
    platforms: ["Web", "Desktop"]
  },
  {
    id: "playground-ai",
    name: "Playground AI",
    company: "Playground",
    category: "Image Generation",
    shortDescription: "A free-to-use online AI image creator with strong mixed-model capabilities.",
    detailedDescription: "Playground is a free-to-use platform that lets you create and edit images like a pro. It supports Stable Diffusion and its own proprietary models to generate highly detailed art.",
    pricing: "Freemium",
    pricingDetails: "Free tier allows 100 images per day. Pro tiers offer faster generations and custom canvas tools.",
    difficulty: "Intermediate",
    useCases: ["Image Generation", "Design"],
    features: {
      basic: ["Text-to-image", "Image-to-image"],
      advanced: ["Mixed image editing on a canvas", "Custom filters", "Outpainting"]
    },
    pros: ["Extremely generous free tier", "Canvas feature allows for complex image composition"],
    cons: ["Interface can be a bit overwhelming with many toggles"],
    ratings: { performance: 8, speed: 8, accuracy: 7, easeOfUse: 7 },
    tags: ["Free tier", "Canvas mode"],
    websiteUrl: "https://playgroundai.com",
    platforms: ["Web"]
  },
  {
    id: "ideogram",
    name: "Ideogram",
    company: "Ideogram",
    category: "Image Generation",
    shortDescription: "An AI image generator exceptional at rendering accurate text within images.",
    detailedDescription: "Ideogram specializes in solving one of AI generation's hardest problems: spelling. It generates highly stylized images, logos, and posters with perfectly spelled text.",
    pricing: "Freemium",
    pricingDetails: "Free daily credits. Paid plans for commercial usage and private generations.",
    difficulty: "Beginner",
    useCases: ["Image Generation", "Business", "Design"],
    features: {
      basic: ["Text-to-image", "Typography integration"],
      advanced: ["Logo generation", "Poster design mode"]
    },
    pros: ["The absolute best at generating text in images", "Very fast", "Great community feed"],
    cons: ["Less focus on photorealism compared to Midjourney", "Style can sometimes feel repetitive"],
    ratings: { performance: 9, speed: 9, accuracy: 9, easeOfUse: 9 },
    tags: ["Typography", "Logos", "Text in Image"],
    websiteUrl: "https://ideogram.ai",
    platforms: ["Web"]
  },
  {
    id: "krea-ai",
    name: "Krea AI",
    company: "Krea",
    category: "Image Generation",
    shortDescription: "Real-time AI generation and upscaling tool for creatives.",
    detailedDescription: "Krea focuses on real-time creation. As you draw or move shapes on a canvas, the AI generates a high-quality image on the fly. It also features incredible AI upscaling capabilities.",
    pricing: "Freemium",
    pricingDetails: "Free basic limits. Pro plans for higher resolution and real-time limits.",
    difficulty: "Intermediate",
    useCases: ["Image Generation", "Design"],
    features: {
      basic: ["Real-time generation", "AI Upscaling"],
      advanced: ["Webcam to AI generation", "Pattern creation"]
    },
    pros: ["Real-time workflow is magical", "Upscaler adds incredible detail that wasn't previously there"],
    cons: ["Real-time requires a good internet connection", "Can be chaotic to control perfectly"],
    ratings: { performance: 8, speed: 10, accuracy: 7, easeOfUse: 8 },
    tags: ["Real-time", "Upscaling", "Interactive"],
    websiteUrl: "https://www.krea.ai",
    platforms: ["Web"]
  },
  {
    id: "nightcafe",
    name: "NightCafe",
    company: "NightCafe Studio",
    category: "Image Generation",
    shortDescription: "A popular AI art generator app heavily focused on community and challenges.",
    detailedDescription: "NightCafe aggregates several models (Stable Diffusion, DALL-E, standard VQGAN) into a gamified platform where users enter daily art challenges and vote on creations.",
    pricing: "Freemium",
    pricingDetails: "Credit-based system. Free daily credits.",
    difficulty: "Beginner",
    useCases: ["Image Generation", "Entertainment"],
    features: {
      basic: ["Multiple algorithms to choose from", "Social feed"],
      advanced: ["Bulk creation", "Daily challenges"]
    },
    pros: ["Great community features", "Easy way to try many different models in one place"],
    cons: ["Can get expensive if you generate a lot", "Not aimed at professional workflows"],
    ratings: { performance: 7, speed: 8, accuracy: 7, easeOfUse: 9 },
    tags: ["Community", "Art", "Gamified"],
    websiteUrl: "https://creator.nightcafe.studio",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "craiyon",
    name: "Craiyon",
    company: "Craiyon",
    category: "Image Generation",
    shortDescription: "The original free, ad-supported AI image generator (formerly DALL-E mini).",
    detailedDescription: "Craiyon generates basic 9-grid AI images from text prompts completely for free without requiring an account. It's ad-supported and great for quick, meme-like generations.",
    pricing: "Free",
    pricingDetails: "Free (ad-supported). Pro plan removes ads and speeds up generation.",
    difficulty: "Beginner",
    useCases: ["Image Generation", "Entertainment"],
    features: {
      basic: ["Text-to-image (9 concepts at once)"],
      advanced: ["Negative prompts"]
    },
    pros: ["100% free and no login required", "Great for silly concepts and memes"],
    cons: ["Low image quality/resolution", "Ads can be annoying", "Slow generation times"],
    ratings: { performance: 5, speed: 6, accuracy: 5, easeOfUse: 10 },
    tags: ["Free", "Memes", "No Login"],
    websiteUrl: "https://www.craiyon.com",
    platforms: ["Web"]
  }
];
