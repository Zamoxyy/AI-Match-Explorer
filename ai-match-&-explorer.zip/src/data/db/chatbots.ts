import { AITool } from '../../types';

export const chatbots: AITool[] = [
  {
    id: "grok",
    name: "Grok",
    company: "xAI",
    category: "Chatbot",
    shortDescription: "An AI modeled after the Hitchhiker's Guide to the Galaxy, with real-time knowledge via X.",
    detailedDescription: "Grok is an AI developed by xAI, integrated with the X (formerly Twitter) platform. It has fewer filters than many competitors and is designed to answer spicy questions and provide real-time information.",
    pricing: "Paid",
    pricingDetails: "Requires X Premium+ subscription.",
    difficulty: "Beginner",
    useCases: ["Other", "Writing", "Brainstorming"],
    features: {
      basic: ["Real-time access to X data", "Conversational AI"],
      advanced: ["Fun Mode", "Less restrictive safety filters"]
    },
    pros: ["Real-time information from X", "Humorous and less filtered personality"],
    cons: ["Only available to paying X Premium+ subscribers", "Can reflect biases present on X"],
    ratings: { performance: 8, speed: 9, accuracy: 7, easeOfUse: 9 },
    tags: ["Real-time", "Twitter", "Humorous"],
    websiteUrl: "https://grok.x.ai",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "pi-ai",
    name: "Pi AI",
    company: "Inflection",
    category: "Chatbot",
    shortDescription: "A supportive, empathetic conversational AI designed to be a personal companion.",
    detailedDescription: "Pi (Personal Intelligence) is designed to be a supportive and empathetic listener, offering a highly natural conversation flow with realistic voices.",
    pricing: "Free",
    pricingDetails: "Currently free to use.",
    difficulty: "Beginner",
    useCases: ["Other", "Brainstorming", "Studying"],
    features: {
      basic: ["Conversational interface", "Empathetic responses"],
      advanced: ["Realistic voice interactions", "Emotional intelligence"]
    },
    pros: ["Incredibly natural and empathetic tone", "Excellent voice capabilities", "Great for bouncing ideas off"],
    cons: ["Not designed for complex coding or technical tasks", "Cannot generate images"],
    ratings: { performance: 7, speed: 9, accuracy: 8, easeOfUse: 10 },
    tags: ["Companion", "Empathy", "Voice"],
    websiteUrl: "https://pi.ai",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "poe",
    name: "Poe",
    company: "Quora",
    category: "Chatbot",
    shortDescription: "A platform that aggregates multiple AI models (GPT-4, Claude, etc.) in one place.",
    detailedDescription: "Poe allows users to access a wide variety of AI models, including those from OpenAI, Anthropic, and Google, as well as thousands of community-created custom bots.",
    pricing: "Freemium",
    pricingDetails: "Free basic access. Premium subscription for higher limits and access to the best models.",
    difficulty: "Beginner",
    useCases: ["Writing", "Coding", "Studying"],
    features: {
      basic: ["Access to multiple models", "Custom bot creation"],
      advanced: ["Model comparison", "API access options"]
    },
    pros: ["All major AI models in one subscription", "Huge library of user-created bots"],
    cons: ["Message limits even on the paid tier for the heaviest models", "Interface can be cluttered"],
    ratings: { performance: 9, speed: 8, accuracy: 9, easeOfUse: 8 },
    tags: ["Aggregator", "Multiple Models", "Custom Bots"],
    websiteUrl: "https://poe.com",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "youchat",
    name: "YouChat",
    company: "You.com",
    category: "Chatbot",
    shortDescription: "A search-integrated AI assistant that cites its sources.",
    detailedDescription: "You.com's AI assistant combines web search with a conversational interface, similar to Perplexity, allowing you to choose different underlying models.",
    pricing: "Freemium",
    pricingDetails: "Free basic usage. YouPro offers access to advanced models like GPT-4 and Claude 3.",
    difficulty: "Beginner",
    useCases: ["Studying", "Writing", "Other"],
    features: {
      basic: ["AI Search", "Citations", "Conversational AI"],
      advanced: ["Customizable models (Pro)", "Image generation", "Coding mode"]
    },
    pros: ["Good alternative to Perplexity", "Flexible model choices for Pro users"],
    cons: ["Can sometimes be slower than direct model interfaces"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 9 },
    tags: ["Search", "Research", "Multi-model"],
    websiteUrl: "https://you.com",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    category: "Chatbot",
    company: "DeepSeek",
    shortDescription: "A highly capable open-weight AI model with strong coding and math abilities.",
    detailedDescription: "DeepSeek is an open-source AI model known for its exceptional performance in coding and mathematics, often rivaling proprietary models at a fraction of the cost.",
    pricing: "Free",
    pricingDetails: "Free to use via their website or API (extremely cheap).",
    difficulty: "Intermediate",
    useCases: ["Coding", "Studying", "Other"],
    features: {
      basic: ["Conversational chat", "Code generation"],
      advanced: ["Deep reasoning mode (DeepSeek-R1)", "High math proficiency"]
    },
    pros: ["Incredible reasoning and coding abilities for an open model", "Very low API prices", "Fast inference"],
    cons: ["Less general knowledge nuance compared to GPT-4o"],
    ratings: { performance: 9, speed: 9, accuracy: 8, easeOfUse: 8 },
    tags: ["Coding", "Math", "Open Source"],
    websiteUrl: "https://chat.deepseek.com",
    platforms: ["Web", "API"]
  },
  {
    id: "mistral-ai",
    name: "Le Chat (Mistral)",
    company: "Mistral AI",
    category: "Chatbot",
    shortDescription: "A fast, open-weights AI assistant developed in Europe.",
    detailedDescription: "Le Chat is the conversational interface for Mistral AI's highly efficient and powerful open-source models (like Mistral Large), known for speed and strong performance.",
    pricing: "Freemium",
    pricingDetails: "Free to use the chat interface. API is paid.",
    difficulty: "Beginner",
    useCases: ["Writing", "Coding", "Business"],
    features: {
      basic: ["Multilingual chat", "Code generation"],
      advanced: ["Web search integration", "Document analysis"]
    },
    pros: ["Very fast response times", "Strong multilingual capabilities", "European privacy standards"],
    cons: ["Slightly less mature ecosystem than OpenAI"],
    ratings: { performance: 8, speed: 10, accuracy: 8, easeOfUse: 9 },
    tags: ["Fast", "European", "Open Source"],
    websiteUrl: "https://chat.mistral.ai",
    platforms: ["Web", "API"]
  },
  {
    id: "cohere",
    name: "Coral (Cohere)",
    company: "Cohere",
    category: "Chatbot",
    shortDescription: "Enterprise-focused AI for knowledge retrieval and chatbots.",
    detailedDescription: "Coral is a knowledge assistant built on Cohere's Command models, specifically designed for enterprise environments to connect to internal company data securely.",
    pricing: "Paid",
    pricingDetails: "Enterprise pricing.",
    difficulty: "Advanced",
    useCases: ["Business", "Other"],
    features: {
      basic: ["Enterprise search", "Chat"],
      advanced: ["RAG (Retrieval-Augmented Generation)", "Secure data integration"]
    },
    pros: ["Highly secure for corporate data", "Excellent RAG capabilities"],
    cons: ["Not aimed at individual consumers", "Requires enterprise setup"],
    ratings: { performance: 8, speed: 8, accuracy: 9, easeOfUse: 7 },
    tags: ["Enterprise", "RAG", "B2B"],
    websiteUrl: "https://cohere.com",
    platforms: ["Web", "API"]
  },
  {
    id: "ai21-labs",
    name: "Wordtune (AI21)",
    company: "AI21 Labs",
    category: "Writing",
    shortDescription: "AI reading and writing companion powered by AI21's models.",
    detailedDescription: "Wordtune is a writing assistant that helps you rephrase, summarize, and articulate your thoughts more clearly, powered by Jurassic models.",
    pricing: "Freemium",
    pricingDetails: "Free basic rewrites. Pro plans available.",
    difficulty: "Beginner",
    useCases: ["Writing", "Business"],
    features: {
      basic: ["Sentence rewriting", "Tone change"],
      advanced: ["Document summarization", "Browser extension"]
    },
    pros: ["Excellent at contextual rephrasing", "Integrates into many platforms"],
    cons: ["More of a writing tool than a generalized chatbot"],
    ratings: { performance: 8, speed: 9, accuracy: 8, easeOfUse: 10 },
    tags: ["Writing", "Rewriting", "Summarization"],
    websiteUrl: "https://www.wordtune.com",
    platforms: ["Web", "Desktop"]
  },
  {
    id: "kimi-ai",
    name: "Kimi",
    company: "Moonshot AI",
    category: "Chatbot",
    shortDescription: "A Chinese AI assistant known for its massive context window for document reading.",
    detailedDescription: "Kimi by Moonshot AI specializes in processing huge amounts of text (millions of tokens), making it excellent for summarizing entire books or massive codebases.",
    pricing: "Free",
    pricingDetails: "Free to use.",
    difficulty: "Intermediate",
    useCases: ["Studying", "Business", "Other"],
    features: {
      basic: ["Conversational chat", "Web search"],
      advanced: ["Massive document upload capacity", "Long context window"]
    },
    pros: ["Incredible at reading huge documents", "Very strong in Chinese language"],
    cons: ["Primarily focused on the Chinese market", "Less known globally"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 8 },
    tags: ["Long Context", "Document Analysis"],
    websiteUrl: "https://kimi.moonshot.cn",
    platforms: ["Web", "Mobile"]
  },
  {
    id: "sarvam-ai",
    name: "Sarvam Chat",
    company: "Sarvam AI",
    category: "Chatbot",
    shortDescription: "AI models built specifically for Indic languages.",
    detailedDescription: "Sarvam AI focuses on building LLMs that understand and generate Indian languages natively and efficiently.",
    pricing: "Freemium",
    pricingDetails: "API based access.",
    difficulty: "Intermediate",
    useCases: ["Business", "Writing"],
    features: {
      basic: ["Multilingual Indian language support"],
      advanced: ["Voice-to-voice in Indic languages", "Enterprise APIs"]
    },
    pros: ["Best-in-class for Hindi, Tamil, Telugu, etc."],
    cons: ["Very niche use case", "Not a general purpose English assistant"],
    ratings: { performance: 7, speed: 8, accuracy: 8, easeOfUse: 7 },
    tags: ["Indic Languages", "Niche"],
    websiteUrl: "https://www.sarvam.ai",
    platforms: ["Web", "API"]
  }
];
