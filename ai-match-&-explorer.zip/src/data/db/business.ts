import { AITool } from '../../types';

export const businessTools: AITool[] = [
  {
    id: "notion-ai",
    name: "Notion AI",
    company: "Notion",
    category: "Business",
    shortDescription: "AI integrated deeply into the Notion workspace.",
    detailedDescription: "Notion AI brings generative capabilities directly into your Notion pages. It can summarize meeting notes, rewrite paragraphs, extract action items, and brainstorm directly where your remote team works.",
    pricing: "Paid",
    pricingDetails: "$10/user/mo add-on to Notion plans.",
    difficulty: "Beginner",
    useCases: ["Business", "Writing", "Productivity"],
    features: {
      basic: ["Summarize pages", "Fix spelling/grammar"],
      advanced: ["Database autofill", "Q&A across entire Notion workspace"]
    },
    pros: ["Seamlessly integrated if you already use Notion", "Q&A feature is great for finding company docs"],
    cons: ["Not very useful as a standalone chat assistant out of context"],
    ratings: { performance: 8, speed: 9, accuracy: 8, easeOfUse: 10 },
    tags: ["Workspace", "Productivity"],
    websiteUrl: "https://www.notion.so/product/ai",
    platforms: ["Web", "Desktop", "Mobile"]
  },
  {
    id: "clickup-ai",
    name: "ClickUp Brain",
    company: "ClickUp",
    category: "Business",
    shortDescription: "A collection of task management and note-taking AI tools.",
    detailedDescription: "ClickUp Brain acts as a neural network connecting tasks, docs, and people. It can generate project summaries, write standups based on task completion, and answer questions about company roadmaps.",
    pricing: "Paid",
    pricingDetails: "$7/user/mo add-on to ClickUp plans.",
    difficulty: "Intermediate",
    useCases: ["Business", "Productivity"],
    features: {
      basic: ["Task generation", "Summarize comment threads"],
      advanced: ["Automated standups", "Knowledge base querying"]
    },
    pros: ["Deeply embedded in project management workflows", "Great for agile development teams"],
    cons: ["ClickUp itself has a steep learning curve"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 7 },
    tags: ["Project Management", "Agile"],
    websiteUrl: "https://clickup.com/ai",
    platforms: ["Web", "Desktop", "Mobile"]
  },
  {
    id: "tome-ai",
    name: "Tome",
    company: "Tome",
    category: "Business",
    shortDescription: "Generative AI storytelling format that turns prompts into presentations.",
    detailedDescription: "Tome replaces traditional slide decks. You give it a prompt or a document, and it creates a highly visual, interactive 'tome' with structured pages, AI-generated images, and text.",
    pricing: "Freemium",
    pricingDetails: "Free basic tier. Pro plan removes limits and adds custom branding.",
    difficulty: "Beginner",
    useCases: ["Business", "Writing"],
    features: {
      basic: ["Prompt to presentation", "DALL-E image integration"],
      advanced: ["Document to presentation", "Figma/Web integration in slides"]
    },
    pros: ["Produces very modern, mobile-friendly presentations", "Incredibly fast way to draft pitch decks"],
    cons: ["Can be difficult to export perfectly to standard PPTX formatted slides"],
    ratings: { performance: 8, speed: 9, accuracy: 7, easeOfUse: 9 },
    tags: ["Presentations", "Pitch Decks", "Storytelling"],
    websiteUrl: "https://tome.app",
    platforms: ["Web"]
  },
  {
    id: "microsoft-copilot",
    name: "Microsoft Copilot",
    company: "Microsoft",
    category: "Business",
    shortDescription: "AI assistant integrated across Microsoft 365 apps and Windows.",
    detailedDescription: "Formerly Bing Chat, Copilot is now woven into Word, Excel, PowerPoint, Teams, and the Windows OS. It acts as a ubiquitous assistant for knowledge workers.",
    pricing: "Freemium",
    pricingDetails: "Free on the web. Copilot for M365 (Enterprise) is $30/user/mo. Copilot Pro (Individual) is $20/mo.",
    difficulty: "Beginner",
    useCases: ["Business", "Writing", "Productivity"],
    features: {
      basic: ["Web chat", "Image generation"],
      advanced: ["Graph integration (searches your emails/teams messages)", "Excel data analysis"]
    },
    pros: ["Enterprise data protection", "Unmatched integration if you use M365 daily"],
    cons: ["Excel integration can be flaky", "Enterprise pricing is quite high"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 9 },
    tags: ["Enterprise", "Office 365", "Ecosystem"],
    websiteUrl: "https://copilot.microsoft.com",
    platforms: ["Web", "Desktop"]
  },
  {
    id: "slack-ai",
    name: "Slack AI",
    company: "Salesforce",
    category: "Business",
    shortDescription: "Native AI that summarizes channels and threads in Slack.",
    detailedDescription: "Slack AI brings summarization and search capabilities natively inside Slack to help users catch up on missed conversations without reading hundreds of messages.",
    pricing: "Paid",
    pricingDetails: "Paid add-on for Enterprise plans.",
    difficulty: "Beginner",
    useCases: ["Business", "Productivity"],
    features: {
      basic: ["Thread summarization", "Channel recaps"],
      advanced: ["Conversational search across company history"]
    },
    pros: ["Saves enormous amounts of time catching up after PTO", "Data remains within Slack"],
    cons: ["Expensive add-on", "Cannot generate outbound content (like emails)"],
    ratings: { performance: 8, speed: 9, accuracy: 8, easeOfUse: 10 },
    tags: ["Communication", "Summarization"],
    websiteUrl: "https://slack.com/features/ai",
    platforms: ["Web", "Desktop", "Mobile"]
  },
  {
    id: "hubspot-ai",
    name: "HubSpot AI",
    company: "HubSpot",
    category: "Business",
    shortDescription: "Generative AI tools integrated into HubSpot's CRM and Marketing hubs.",
    detailedDescription: "HubSpot's Content Assistant and ChatSpot allow marketers and salespeople to generate emails, blogs, and query CRM data using natural language directly within their existing workflows.",
    pricing: "Freemium",
    pricingDetails: "Included in CRM plans.",
    difficulty: "Intermediate",
    useCases: ["Business", "Marketing", "Sales"],
    features: {
      basic: ["Email drafting", "Blog post generation"],
      advanced: ["CRM report generation via chat", "Workflow automation guidance"]
    },
    pros: ["Eliminates context switching for HubSpot users", "Makes querying complex CRM data much easier"],
    cons: ["Limited usefulness outside the HubSpot ecosystem"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 9 },
    tags: ["CRM", "Marketing", "Sales"],
    websiteUrl: "https://www.hubspot.com/artificial-intelligence",
    platforms: ["Web"]
  },
  {
    id: "adcreative-ai",
    name: "AdCreative.ai",
    company: "AdCreative",
    category: "Business",
    shortDescription: "AI that generates hundreds of conversion-focused ad creatives in seconds.",
    detailedDescription: "AdCreative analyzes successful ad campaigns across the industry to generate banners and ad creatives optimized specifically for high conversion rates (CTR) on platforms like Facebook and Google.",
    pricing: "Paid",
    pricingDetails: "Starts around $21/mo for small startups.",
    difficulty: "Beginner",
    useCases: ["Business", "Marketing", "Design"],
    features: {
      basic: ["Generate ad variations", "Text generation for ad copy"],
      advanced: ["Creative analytics/scoring", "Competitor analysis insights"]
    },
    pros: ["Massive time saver for performance marketing teams", "Data-backed designs perform better than random UI"],
    cons: ["Can feel slightly templated if you rely on it heavily"],
    ratings: { performance: 9, speed: 9, accuracy: 8, easeOfUse: 9 },
    tags: ["Advertising", "Performance Marketing", "Banners"],
    websiteUrl: "https://www.adcreative.ai",
    platforms: ["Web"]
  }
];
