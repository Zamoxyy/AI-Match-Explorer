import { AITool } from '../../types';

export const codingTools: AITool[] = [
  {
    id: "amazon-codewhisperer",
    name: "AWS Q Developer",
    company: "Amazon",
    category: "Coding",
    shortDescription: "Amazon's AI coding companion designed to help developers build on AWS.",
    detailedDescription: "Formerly CodeWhisperer, Amazon Q Developer is an AI pair programmer that provides real-time code suggestions and is deeply integrated with the AWS ecosystem, offering specific advice on AWS APIs and security scanning.",
    pricing: "Freemium",
    pricingDetails: "Free for individual use. Pro plan for enterprise features.",
    difficulty: "Intermediate",
    useCases: ["Coding", "Business"],
    features: {
      basic: ["Inline code completion", "Code explanation"],
      advanced: ["AWS API optimization", "Security vulnerability scanning", "Legacy code upgrading"]
    },
    pros: ["Unbeatable if you are heavily building on AWS", "Free tier is very generous", "Built-in security scans"],
    cons: ["Less general-purpose than GitHub Copilot outside of AWS", "Can be heavy on IDE resources"],
    ratings: { performance: 8, speed: 8, accuracy: 8, easeOfUse: 8 },
    tags: ["AWS", "Enterprise", "Security"],
    websiteUrl: "https://aws.amazon.com/q/developer/",
    platforms: ["Desktop", "API"]
  },
  {
    id: "windsurf",
    name: "Windsurf",
    company: "Codeium",
    category: "Coding",
    shortDescription: "A powerful, agentic AI IDE that understands your entire codebase.",
    detailedDescription: "Windsurf is a next-generation AI IDE built by Codeium. It features deeply integrated agents that can write code, run commands, and understand complex project structures, directly challenging Cursor.",
    pricing: "Freemium",
    pricingDetails: "Free tier available. Pro tiers for advanced models.",
    difficulty: "Advanced",
    useCases: ["Coding"],
    features: {
      basic: ["AI Code generation", "Inline chat"],
      advanced: ["Agentic workflows (Cascade)", "Deep codebase indexing", "Terminal integration"]
    },
    pros: ["Extremely powerful agentic capabilities", "Uses Codeium's fast autocomplete engine", "Great context awareness"],
    cons: ["Requires switching IDEs", "Still relatively new with some bugs"],
    ratings: { performance: 9, speed: 9, accuracy: 9, easeOfUse: 8 },
    tags: ["IDE", "Agentic", "Cursor alternative"],
    websiteUrl: "https://codeium.com/windsurf",
    platforms: ["Desktop"]
  },
  {
    id: "aider",
    name: "Aider",
    company: "Open Source",
    category: "Coding",
    shortDescription: "An open-source AI pair programmer in your terminal.",
    detailedDescription: "Aider is a command-line tool that lets you pair program with LLMs. It edits files directly in your local git repository and automatically commits changes with descriptive messages.",
    pricing: "Free",
    pricingDetails: "The tool is free, but you must pay for your own API keys (OpenAI, Anthropic, etc.).",
    difficulty: "Advanced",
    useCases: ["Coding"],
    features: {
      basic: ["Terminal-based chat", "Multi-file editing"],
      advanced: ["Automatic git commits", "Works with any LLM via API", "Voice coding support"]
    },
    pros: ["Incredibly efficient for CLI workflows", "Editor agnostic (use Vim, Emacs, VS Code)", "Auto-commits are a huge time saver"],
    cons: ["Requires CLI knowledge", "Setting up API keys and limits can be tedious"],
    ratings: { performance: 9, speed: 8, accuracy: 8, easeOfUse: 6 },
    tags: ["CLI", "Open Source", "Git integration"],
    websiteUrl: "https://aider.chat",
    platforms: ["Desktop"]
  }
];
