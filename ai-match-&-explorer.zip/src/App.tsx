import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Sparkles, BrainCircuit } from 'lucide-react';
import Explorer from './pages/Explorer';
import Recommender from './pages/Recommender';
import { cn } from './lib/utils';

export default function App() {
  const [activeTab, setActiveTab] = useState<'explorer' | 'recommender'>('recommender');

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 w-full border-b border-fuchsia-100 bg-white/60 px-4 backdrop-blur-lg sm:px-6 lg:px-8 shadow-sm">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex bg-gradient-to-br from-violet-500 to-fuchsia-600 p-2 rounded-xl text-white shadow-md shadow-fuchsia-200">
              <BrainCircuit className="h-5 w-5" />
            </div>
            <span className="text-2xl font-extrabold tracking-tighter bg-gradient-to-r from-violet-700 to-fuchsia-600 bg-clip-text text-transparent">AI Match</span>
          </div>
          <nav className="flex space-x-1 sm:space-x-4">
            <button
              onClick={() => setActiveTab('recommender')}
              className={cn(
                "flex items-center gap-2 rounded-full px-5 py-2 text-sm font-medium transition-all group",
                activeTab === 'recommender'
                  ? "bg-gradient-to-r from-violet-100 to-fuchsia-100 text-violet-900 shadow-sm ring-1 ring-fuchsia-200"
                  : "text-zinc-500 hover:bg-zinc-100/80 hover:text-zinc-900"
              )}
            >
              <Sparkles className={cn("h-4 w-4", activeTab === 'recommender' && "text-fuchsia-600")} />
              <span className="hidden sm:inline">Find My AI</span>
            </button>
            <button
              onClick={() => setActiveTab('explorer')}
              className={cn(
                "flex items-center gap-2 rounded-full px-5 py-2 text-sm font-medium transition-all group",
                activeTab === 'explorer'
                  ? "bg-gradient-to-r from-violet-100 to-fuchsia-100 text-violet-900 shadow-sm ring-1 ring-fuchsia-200"
                  : "text-zinc-500 hover:bg-zinc-100/80 hover:text-zinc-900"
              )}
            >
              <Search className={cn("h-4 w-4", activeTab === 'explorer' && "text-fuchsia-600")} />
              <span className="hidden sm:inline">Explorer</span>
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <AnimatePresence mode="wait">
          {activeTab === 'recommender' ? (
            <motion.div
              key="recommender"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <Recommender />
            </motion.div>
          ) : (
            <motion.div
              key="explorer"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <Explorer />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
