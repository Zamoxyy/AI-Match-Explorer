import { useEffect } from 'react';
import { motion } from 'motion/react';
import { X, ExternalLink, Star } from 'lucide-react';
import { AITool } from '../types';
import { Button } from './ui/Button';
import { Badge } from './ui/Badge';

interface AIModalProps {
  tool: AITool;
  onClose: () => void;
}

export function AIModal({ tool, onClose }: AIModalProps) {
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-zinc-900/50 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative flex w-full max-w-4xl max-h-[90vh] flex-col overflow-hidden rounded-2xl bg-white shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-100 p-6">
          <div>
            <h2 className="text-2xl font-bold text-zinc-900">{tool.name}</h2>
            <p className="text-zinc-500">{tool.company}</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="text-sm px-3 py-1 hidden sm:inline-flex">
              {tool.category}
            </Badge>
            <button
              onClick={onClose}
              className="rounded-full p-2 text-zinc-400 hover:bg-zinc-100 hover:text-zinc-600 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            <div className="md:col-span-2 space-y-8">
              <section>
                <h3 className="text-lg font-semibold mb-2">Overview</h3>
                <p className="text-zinc-600 leading-relaxed">{tool.detailedDescription}</p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">Key Features</h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-sm text-zinc-900 mb-2">Basic</h4>
                    <ul className="space-y-1">
                      {tool.features.basic.map((f, i) => (
                        <li key={i} className="text-zinc-600 text-sm flex items-start gap-2">
                          <span className="text-fuchsia-500 mt-0.5">•</span> {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm text-zinc-900 mb-2">Advanced</h4>
                    <ul className="space-y-1">
                      {tool.features.advanced.map((f, i) => (
                        <li key={i} className="text-zinc-600 text-sm flex items-start gap-2">
                          <span className="text-fuchsia-500 mt-0.5">•</span> {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </section>

              <section className="grid sm:grid-cols-2 gap-4">
                <div className="bg-emerald-50 rounded-xl p-4">
                  <h3 className="font-semibold text-emerald-900 mb-2">Advantages</h3>
                  <ul className="space-y-1">
                    {tool.pros.map((p, i) => (
                      <li key={i} className="text-emerald-800 text-sm flex items-start gap-2">
                         <span className="text-emerald-500 mt-0.5">+</span> {p}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-rose-50 rounded-xl p-4">
                  <h3 className="font-semibold text-rose-900 mb-2">Disadvantages</h3>
                  <ul className="space-y-1">
                    {tool.cons.map((c, i) => (
                      <li key={i} className="text-rose-800 text-sm flex items-start gap-2">
                        <span className="text-rose-500 mt-0.5">-</span> {c}
                      </li>
                    ))}
                  </ul>
                </div>
              </section>
            </div>

            <div className="space-y-6 md:border-l md:border-zinc-100 md:pl-6">
              <div>
                <h3 className="text-sm font-semibold text-zinc-900 uppercase tracking-wider mb-3">Pricing</h3>
                <Badge variant={tool.pricing === 'Free' ? 'success' : tool.pricing === 'Freemium' ? 'warning' : 'outline'} className="mb-2">
                  {tool.pricing}
                </Badge>
                <p className="text-sm text-zinc-600">{tool.pricingDetails}</p>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-zinc-900 uppercase tracking-wider mb-3">Ratings</h3>
                <div className="space-y-2">
                  {Object.entries(tool.ratings).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between">
                      <span className="text-sm text-zinc-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                      <div className="flex items-center gap-1">
                        <span className="text-sm font-medium">{value}</span>
                        <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-zinc-900 uppercase tracking-wider mb-3">Tags & Use Cases</h3>
                <div className="flex flex-wrap gap-2 mb-4">
                  {tool.tags.map((tag, i) => (
                    <Badge key={`tag-${i}`} variant="secondary" className="bg-fuchsia-50 text-fuchsia-700">{tag}</Badge>
                  ))}
                </div>
                <div className="flex flex-wrap gap-2">
                  {tool.useCases.map((uc, i) => (
                    <Badge key={`uc-${i}`} variant="outline">{uc}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-zinc-100 p-6 bg-zinc-50 flex justify-end">
          <Button onClick={() => window.open(tool.websiteUrl, '_blank')} className="gap-2">
            Visit Website <ExternalLink className="h-4 w-4" />
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
