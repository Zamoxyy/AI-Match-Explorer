import * as React from "react"
import { cn } from "../../lib/utils"

export interface BadgeProps {
  className?: string;
  variant?: 'default' | 'secondary' | 'outline' | 'success' | 'warning';
  children?: React.ReactNode;
}

function Badge({ className, variant = "default", children, ...props }: BadgeProps & React.HTMLAttributes<HTMLDivElement>) {
  const variants = {
    default: "border-transparent bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow",
    secondary: "border-transparent bg-zinc-100 text-zinc-900 hover:bg-zinc-200",
    outline: "text-zinc-950 border-zinc-200",
    success: "border-transparent bg-emerald-100 text-emerald-800",
    warning: "border-transparent bg-amber-100 text-amber-800",
  }

  return (
    <div className={cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-zinc-950 focus:ring-offset-2", variants[variant], className)} {...props}>
      {children}
    </div>
  )
}

export { Badge }
