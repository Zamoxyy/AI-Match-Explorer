import { AITool } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from './ui/Card';
import { Badge } from './ui/Badge';
import { Button } from './ui/Button';

interface AICardProps {
  tool: AITool;
  onClick: (tool: AITool) => void;
}

export function AICard({ tool, onClick }: AICardProps) {
  return (
    <Card className="flex flex-col h-full hover:shadow-md transition-shadow cursor-pointer" onClick={() => onClick(tool)}>
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start gap-4">
          <div>
            <CardTitle className="text-xl mb-1">{tool.name}</CardTitle>
            <CardDescription className="text-xs">{tool.company}</CardDescription>
          </div>
          <Badge variant={tool.pricing === 'Free' ? 'success' : tool.pricing === 'Freemium' ? 'warning' : 'outline'}>
            {tool.pricing}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-zinc-600 mb-4 line-clamp-3">{tool.shortDescription}</p>
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary">{tool.category}</Badge>
          <Badge variant="secondary">{tool.difficulty}</Badge>
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Button variant="outline" className="w-full" onClick={(e) => {
          e.stopPropagation();
          onClick(tool);
        }}>
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
}
