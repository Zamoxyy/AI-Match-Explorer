import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, ChevronRight, CheckCircle2, RotateCcw } from 'lucide-react';
import { aiDatabase } from '../data/ai-db';
import { AITool, Category, Difficulty, UserPreferences } from '../types';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { AIModal } from '../components/AIModal';

export default function Recommender() {
  const [step, setStep] = useState(1);
  const [preferences, setPreferences] = useState<Partial<UserPreferences>>({});
  const [results, setResults] = useState<{ topMatch: AITool | null; topMatchScore: number; alternatives: { tool: AITool, score: number }[] } | null>(null);
  const [selectedTool, setSelectedTool] = useState<AITool | null>(null);

  const totalSteps = 5;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      calculateRecommendations();
    }
  };

  const calculateRecommendations = () => {
    // 1. Initial Filtering
    let viableTools = [...aiDatabase];

    // Budget filtering
    if (preferences.budget === 'Free only') {
      viableTools = viableTools.filter(t => t.pricing === 'Free');
    } else if (preferences.budget === 'Freemium') {
      viableTools = viableTools.filter(t => t.pricing === 'Free' || t.pricing === 'Freemium');
    }
    // 'Paid tools OK' means no filter needed.

    // Platform filtering - lax match
    if (preferences.platformSelection && preferences.platformSelection.length > 0) {
      viableTools = viableTools.filter(t => 
        t.platforms.some(p => preferences.platformSelection?.includes(p as any))
      );
    }

    // 2. Scoring
    const scoredTools = viableTools.map(tool => {
      let score = 0;
      let maxPossibleScore = 0;
      const reasons: string[] = [];

      // Use Case Match
      maxPossibleScore += 50;
      if (tool.category === preferences.useCase || tool.useCases.includes(preferences.useCase as string)) {
        score += 50;
        reasons.push(`Perfect for ${preferences.useCase}`);
      } else {
        score += 0; 
      }

      // Skill Level Match
      maxPossibleScore += 20;
      if (tool.difficulty === preferences.skillLevel) {
        score += 20;
        reasons.push(`Matches your ${preferences.skillLevel.toLowerCase()} skill level`);
      } else if (
        (preferences.skillLevel === 'Beginner' && tool.difficulty === 'Intermediate') ||
        (preferences.skillLevel === 'Intermediate' && (tool.difficulty === 'Beginner' || tool.difficulty === 'Advanced')) ||
        (preferences.skillLevel === 'Advanced' && tool.difficulty === 'Intermediate')
      ) {
        score += 10;
      }

      // Priority Scoring
      maxPossibleScore += 30; // Max achievable is typically around 30 points (20 quality * 1.5)
      switch (preferences.priority) {
        case 'Best quality':
          score += (tool.ratings.performance + tool.ratings.accuracy) * 1.5;
          if (tool.ratings.performance >= 9) reasons.push('Industry-leading quality');
          break;
        case 'Fastest results':
          score += (tool.ratings.speed * 2) + 10;
          if (tool.ratings.speed >= 9) reasons.push('Lightning fast generation');
          break;
        case 'Easiest to use':
          score += (tool.ratings.easeOfUse * 2) + 10;
          if (tool.ratings.easeOfUse >= 9) reasons.push('Incredibly intuitive interface');
          break;
        case 'Most powerful':
          score += (tool.ratings.performance * 2) + 10;
          if (tool.features.advanced.length > 2) reasons.push('Packed with pro features');
          break;
      }

      // Calculate confidence percentage
      const confidence = Math.min(Math.round((score / maxPossibleScore) * 100), 99);

      return { tool, score: confidence, reasons: reasons.slice(0, 2) };
    });

    // Sort by score
    scoredTools.sort((a, b) => b.score - a.score);

    const validMatches = scoredTools.filter(t => t.score > 0);

    if (validMatches.length > 0) {
      // Attach reasons to the tools dynamically for the UI
      (validMatches[0].tool as any).matchReasons = validMatches[0].reasons;
      validMatches.slice(1, 4).forEach(m => {
        (m.tool as any).matchReasons = m.reasons;
      });

      setResults({
        topMatch: validMatches[0].tool,
        topMatchScore: validMatches[0].score,
        alternatives: validMatches.slice(1, 4).map(m => ({ tool: m.tool, score: m.score })),
      });
    } else {
      // Fallback if no perfect match
      setResults({
        topMatch: scoredTools.length > 0 ? scoredTools[0].tool : aiDatabase[0],
        topMatchScore: scoredTools.length > 0 ? scoredTools[0].score : 50,
        alternatives: scoredTools.slice(1, 4).map(m => ({ tool: m.tool, score: m.score })),
      });
    }
  };

  const handleSelect = (key: keyof UserPreferences, value: any) => {
    setPreferences(prev => {
      if (key === 'platformSelection') {
        const current = prev.platformSelection || [];
        if (current.includes(value)) {
          return { ...prev, [key]: current.filter(v => v !== value) };
        }
        return { ...prev, [key]: [...current, value] };
      }
      return { ...prev, [key]: value };
    });
  };

  const getStepContent = () => {
    switch (step) {
      case 1:
        return (
          <SelectionStep
            title="What do you want to use AI for?"
            options={['Coding', 'Writing', 'Image Generation', 'Video Creation', 'Studying', 'Business', 'Other']}
            selected={preferences.useCase}
            onSelect={(val) => handleSelect('useCase', val)}
          />
        );
      case 2:
        return (
          <SelectionStep
            title="What is your current skill level?"
            options={['Beginner', 'Intermediate', 'Advanced']}
            selected={preferences.skillLevel}
            onSelect={(val) => handleSelect('skillLevel', val)}
          />
        );
      case 3:
        return (
          <SelectionStep
            title="What is your budget?"
            options={['Free only', 'Freemium', 'Paid tools OK']}
            selected={preferences.budget}
            onSelect={(val) => handleSelect('budget', val)}
          />
        );
      case 4:
        return (
          <SelectionStep
            title="What matters most to you?"
            options={['Best quality', 'Fastest results', 'Easiest to use', 'Most powerful']}
            selected={preferences.priority}
            onSelect={(val) => handleSelect('priority', val)}
          />
        );
      case 5:
        return (
          <SelectionStep
            title="Where do you want to use it?"
            subtitle="Select all that apply."
            options={['Web', 'Mobile', 'Desktop', 'API']}
            selected={preferences.platformSelection}
            onSelect={(val) => handleSelect('platformSelection', val)}
            multi
          />
        );
      default:
        return null;
    }
  };

  if (results) {
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-zinc-900">Your AI Matches</h2>
            <p className="text-zinc-500 mt-1">Based on your specific needs and preferences.</p>
          </div>
          <Button variant="outline" onClick={() => { setResults(null); setStep(1); setPreferences({}); }} className="gap-2">
            <RotateCcw className="h-4 w-4" /> Start Over
          </Button>
        </div>

        {results.topMatch && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🥇</span>
              <h3 className="text-xl font-bold text-zinc-800">Best Match</h3>
            </div>
            <Card className="border-violet-200 bg-gradient-to-br from-violet-50 to-fuchsia-50/30 relative overflow-hidden shadow-sm">
              <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl from-fuchsia-100 to-violet-100 rounded-bl-full -z-10 opacity-60" />
              <CardContent className="p-6 sm:p-8">
                <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-2">
                      <h4 className="text-2xl font-bold text-zinc-900">{results.topMatch.name}</h4>
                      <Badge className="bg-gradient-to-r from-violet-600 to-fuchsia-500 shadow-sm border-0">Top Recommended</Badge>
                      <Badge variant="outline" className="border-violet-200 text-violet-700 bg-violet-50/80 backdrop-blur-sm">
                        {results.topMatchScore}% Match
                      </Badge>
                    </div>
                    <p className="text-zinc-600 mb-4">{results.topMatch.shortDescription}</p>
                    
                    <div className="space-y-2 mb-6">
                      <p className="text-sm font-semibold text-zinc-900">Why it's recommended:</p>
                      <ul className="space-y-1">
                        {((results.topMatch as any).matchReasons || []).map((reason: string, i: number) => (
                          <li key={i} className="text-sm text-violet-800 flex items-center gap-2">
                            <CheckCircle2 className="h-4 w-4 text-fuchsia-500" /> {reason}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex gap-2 text-sm text-zinc-500">
                      <span className="font-medium bg-white px-2 py-1 border border-zinc-200 rounded-md">
                        {results.topMatch.pricing}
                      </span>
                      <span className="font-medium bg-white px-2 py-1 border border-zinc-200 rounded-md">
                        {results.topMatch.difficulty}
                      </span>
                    </div>
                  </div>
                  <div className="w-full md:w-auto shrink-0 flex flex-col gap-3">
                    <div className="bg-white p-4 rounded-xl border border-zinc-200 shadow-sm">
                      <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">Key Strengths</div>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center gap-4 text-sm">
                          <span>Quality</span>
                          <span className="font-bold">{results.topMatch.ratings.performance}/10</span>
                        </div>
                        <div className="flex justify-between items-center gap-4 text-sm">
                          <span>Speed</span>
                          <span className="font-bold">{results.topMatch.ratings.speed}/10</span>
                        </div>
                        <div className="flex justify-between items-center gap-4 text-sm">
                          <span>Ease</span>
                          <span className="font-bold">{results.topMatch.ratings.easeOfUse}/10</span>
                        </div>
                      </div>
                    </div>
                    <Button onClick={() => setSelectedTool(results.topMatch)}>View Full Details</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {results.alternatives.length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-zinc-800 mt-8">Great Alternatives</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.alternatives.map((alt) => (
                <Card key={alt.tool.id} className="flex flex-col h-full hover:border-fuchsia-200 transition-colors">
                   <CardContent className="p-5 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-lg text-zinc-900">{alt.tool.name}</h4>
                      <Badge variant="outline" className="text-xs bg-zinc-50 text-zinc-600">{alt.score}% Match</Badge>
                    </div>
                    <div className="flex gap-2 mb-3">
                      <Badge variant="secondary" className="text-[10px] uppercase">{alt.tool.pricing}</Badge>
                      <Badge variant="secondary" className="text-[10px] uppercase">{alt.tool.difficulty}</Badge>
                    </div>
                    <p className="text-sm text-zinc-600 mb-4 flex-1 line-clamp-3">{alt.tool.shortDescription}</p>
                    <div className="bg-zinc-50 p-3 rounded-lg mb-4 text-sm text-zinc-700">
                      <span className="font-medium text-zinc-900">Why consider: </span>
                      {((alt.tool as any).matchReasons && (alt.tool as any).matchReasons.length > 0) ? (alt.tool as any).matchReasons[0] : `Good for ${alt.tool.category}`}
                    </div>
                    <Button variant="outline" className="w-full" onClick={() => setSelectedTool(alt.tool)}>
                      Compare
                    </Button>
                   </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
        
        <AnimatePresence>
        {selectedTool && (
          <AIModal tool={selectedTool} onClose={() => setSelectedTool(null)} />
        )}
      </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-12">
      <div className="mb-8">
        <div className="flex items-center gap-4 text-sm font-medium text-zinc-400 mb-4">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center border-2 transition-colors ${step === i + 1 ? 'border-fuchsia-600 bg-fuchsia-600 text-white' : step > i + 1 ? 'border-fuchsia-600 bg-fuchsia-50 text-fuchsia-600' : 'border-zinc-200'}`}>
                {step > i + 1 ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
              </div>
              {i < totalSteps - 1 && <div className={`w-8 h-1 rounded-full ${step > i + 1 ? 'bg-fuchsia-600' : 'bg-zinc-200'}`} />}
            </div>
          ))}
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-zinc-900">Let's find your perfect AI</h1>
        <p className="text-zinc-500 mt-2">Answer a few quick questions and we'll do the match-making.</p>
      </div>

      <Card className="shadow-lg border-zinc-200/60 overflow-hidden">
        <div className="bg-fuchsia-50/50 p-6 sm:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {getStepContent()}
            </motion.div>
          </AnimatePresence>
        </div>
        <div className="border-t border-zinc-100 bg-white p-6 sm:px-8 flex justify-between items-center">
          <Button 
            variant="ghost" 
            onClick={() => setStep(Math.max(1, step - 1))}
            disabled={step === 1}
            className="text-zinc-500"
          >
            Back
          </Button>
          <Button 
            onClick={handleNext} 
            className="gap-2"
          >
            {step === totalSteps ? 'Show Recommendations' : 'Next Step'} 
            {step < totalSteps && <ChevronRight className="h-4 w-4" />}
          </Button>
        </div>
      </Card>
    </div>
  );
}

function SelectionStep({ title, subtitle, options, selected, onSelect, multi = false }: { 
  title: string; 
  subtitle?: string; 
  options: string[]; 
  selected: any; 
  onSelect: (val: string) => void;
  multi?: boolean;
}) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-zinc-900">{title}</h2>
        {subtitle && <p className="text-sm text-zinc-500 mt-1">{subtitle}</p>}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {options.map((option) => {
          const isSelected = multi ? (selected || []).includes(option) : selected === option;
          return (
            <button
              key={option}
              onClick={() => onSelect(option)}
              className={`flex items-center p-4 rounded-xl border-2 text-left transition-all ${
                isSelected 
                  ? 'border-fuchsia-600 bg-white shadow-sm ring-1 ring-fuchsia-600/10' 
                  : 'border-zinc-200 bg-white hover:border-fuchsia-300 hover:bg-zinc-50'
              }`}
            >
              <div className={`flex-shrink-0 w-5 h-5 rounded-full border flex items-center justify-center mr-3 ${
                isSelected ? (!multi ? 'border-[6px] border-fuchsia-600' : 'bg-fuchsia-600 border-fuchsia-600') : 'border-zinc-300'
              }`}>
                {multi && isSelected && <CheckCircle2 className="h-3 w-3 text-white absolute" />}
              </div>
              <span className={`font-medium ${isSelected ? 'text-fuchsia-900' : 'text-zinc-700'}`}>
                {option}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
