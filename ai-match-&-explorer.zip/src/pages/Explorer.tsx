import { useState, useMemo } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Search, Filter } from 'lucide-react';
import { aiDatabase } from '../data/ai-db';
import { AICard } from '../components/AICard';
import { AIModal } from '../components/AIModal';
import { Input } from '../components/ui/Input';
import { AITool, Category, Pricing, Difficulty } from '../types';

const CATEGORIES: Category[] = ['Chatbot', 'Coding', 'Image Generation', 'Video Creation', 'Writing', 'Audio/Voice', 'Business', 'Studying', 'Other'];
const PRICING: Pricing[] = ['Free', 'Freemium', 'Paid'];
const DIFFICULTIES: Difficulty[] = ['Beginner', 'Intermediate', 'Advanced'];

export default function Explorer() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [selectedPricing, setSelectedPricing] = useState<Pricing | 'All'>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty | 'All'>('All');
  
  const [selectedTool, setSelectedTool] = useState<AITool | null>(null);

  const filteredTools = useMemo(() => {
    return aiDatabase.filter(tool => {
      const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            tool.shortDescription.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory;
      const matchesPricing = selectedPricing === 'All' || tool.pricing === selectedPricing;
      const matchesDifficulty = selectedDifficulty === 'All' || tool.difficulty === selectedDifficulty;
      
      return matchesSearch && matchesCategory && matchesPricing && matchesDifficulty;
    });
  }, [searchQuery, selectedCategory, selectedPricing, selectedDifficulty]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight text-zinc-900">AI Explorer</h1>
          <p className="text-zinc-600 mt-2 font-medium">Discover and compare the best AI tools for your workflow.</p>
        </div>
        <div className="w-full md:w-auto flex-1 max-w-md relative">
          <Search className="absolute left-3 top-1/2 -tranzinc-y-1/2 h-4 w-4 text-zinc-400" />
          <Input 
            type="text" 
            placeholder="Search AI tools..." 
            className="pl-9 bg-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex justify-start items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <Filter className="h-4 w-4 text-zinc-400 shrink-0 mr-1" />
        
        <select 
          className="text-sm border border-fuchsia-200 rounded-md py-1.5 px-3 bg-white/80 text-zinc-700 outline-none focus:ring-2 focus:ring-fuchsia-500 shadow-sm"
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value as any)}
        >
          <option value="All">All Categories</option>
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>

        <select 
          className="text-sm border border-fuchsia-200 rounded-md py-1.5 px-3 bg-white/80 text-zinc-700 outline-none focus:ring-2 focus:ring-fuchsia-500 shadow-sm"
          value={selectedPricing}
          onChange={(e) => setSelectedPricing(e.target.value as any)}
        >
          <option value="All">Any Price</option>
          {PRICING.map(p => <option key={p} value={p}>{p}</option>)}
        </select>

        <select 
          className="text-sm border border-fuchsia-200 rounded-md py-1.5 px-3 bg-white/80 text-zinc-700 outline-none focus:ring-2 focus:ring-fuchsia-500 shadow-sm"
          value={selectedDifficulty}
          onChange={(e) => setSelectedDifficulty(e.target.value as any)}
        >
          <option value="All">Any Difficulty</option>
          {DIFFICULTIES.map(d => <option key={d} value={d}>{d}</option>)}
        </select>
      </div>

      {filteredTools.length === 0 ? (
        <div className="text-center py-20">
          <div className="bg-zinc-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="h-8 w-8 text-zinc-400" />
          </div>
          <h3 className="text-lg font-medium text-zinc-900">No AI tools found</h3>
          <p className="text-zinc-500">Try adjusting your search or filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <AnimatePresence>
            {filteredTools.map((tool) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2 }}
                key={tool.id}
              >
                <AICard tool={tool} onClick={setSelectedTool} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      <AnimatePresence>
        {selectedTool && (
          <AIModal tool={selectedTool} onClose={() => setSelectedTool(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}
